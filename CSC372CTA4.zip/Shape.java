package Bank;

public abstract class Shape {
	public abstract double surface_Area() ;
	public abstract double volume();
	}
